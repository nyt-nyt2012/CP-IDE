#include "testlib.h"

#include <cmath>
#include <cstdlib>
#include <string>

using namespace std;

/* 数值比较：允许前导零、小数误差等写法差异 */
static bool numericEqual(const string &a, const string &b) {
    char *endA = 0;
    char *endB = 0;
    double x = strtod(a.c_str(), &endA);
    double y = strtod(b.c_str(), &endB);
    if (endA == a.c_str() || endB == b.c_str()) return false;
    if (*endA != '\0' || *endB != '\0') return false;
    double diff = fabs(x - y);
    double scale = max(1.0, max(fabs(x), fabs(y)));
    return diff <= 1e-6 * scale;
}

int main(int argc, char *argv[]) {
    registerTestlibCmd(argc, argv);

    int index = 0;
    while (!ans.seekEof() || !ouf.seekEof()) {
        ++index;
        if (ans.seekEof() || ouf.seekEof()) {
            quitf(_wa, "token count mismatch at token %d", index);
        }
        string expected = ans.readWord();
        string got = ouf.readWord();
        if (!numericEqual(got, expected)) {
            quitf(_wa, "token %d mismatch: got '%s', expected '%s'",
                  index, got.c_str(), expected.c_str());
        }
    }

    quitf(_ok, "answer is correct");
}
